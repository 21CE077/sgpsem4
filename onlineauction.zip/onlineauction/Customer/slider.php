<section id="featured">
	 
	<!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
              <li>
                <img src="img/slides/img14.jpg" alt="" style="width:100%;height:450px" />
                
              </li>
              
              <li>
                <img src="img/slides/img15.jpg" alt="" style="width:100%;height:450px" />
                
              </li>
			   <li>
                <img src="img/slides/img16.jpg" alt="" style="width:100%;height:450px" />
                
              </li>
			   <li>
                <img src="img/slides/img1.jpg" alt="" style="width:100%;height:450px" />
                
              </li>
			  <li>
                <img src="img/slides/img2.jpg" alt="" style="width:100%;height:450px" />
               
              </li>
            </ul>
        </div>
	<!-- end slider -->
 
	</section>