<HTML>
<HEAD>
<?php
	  session_start();
	  include("../class/DataClass.php");
	  include("csslink.php");
	?>
	
	<?php
	    $msg="";
	    $dc=new DataClass();
	?>
	<style type="text/css">
	  p{font-size:18px;text-align:justify;color:navy}
	  li{font-size:18px;color:navy}
	</style>
	
</HEAD>
<HTML>
<BODY>
<div id="wrapper">
  <?php
   include("header.php");
   include("slider.php");
  ?>
  <form name="frm" action="#" method="post">
    <div class="container">
      <div class="row" style="margin-top:10px">
        <div class="col-md-12">
		<p>
		irtual auctions on the internet. The seller sells the product or service to the person who bids the highest price. For sellers, online auctions open up new sales channels for new products and offer buyers favorable purchasing conditions.
Online auctions have effectively created a giant virtual marketplace where people can gather to buy, sell, trade and check out the goods of the day. They're enormously popular, high-traffic venues where you can begin selling product almost immediately, with...
</p>
<ul>
<li>No overhead or upfront costs</li>
<li>No sales staff or distributors
<li>No website of your own
<li>No initial investment 
</ul>
<p>
In this massive marketplace, the auction site that rules the game is eBay. According to the Neilson Ratings, eBay is among the top ten most-trafficked sites on the Internet. eBay leads the online auction industry with a more than 60 percent share of the market, while its closest competitor, Yahoo! Auctions, is only half its size. Amazon.com Auctions follows at a distant third.
</p>
<p>
The amount of traffic these sites attract make online auctions an ideal place to capitalize on readily available, widespread exposure. However, know this: The competition is fierce in popular categories, and your product can easily get lost among the hundreds of listings.
</p>
<p>
So whether you're selling a knick-knack or two or becoming a full-time baseball card dealer, there are a number of things you must do to harness the volumes of traffic heading your way and generate the highest profits possible:
</p>
		
		</div>
	  </div>
	 </div>
  
  
  </form>
  <?php
   include("footer.php");
   
  ?>
  
 </div> 
 <?php
 include("jslink.php");
?> 
</BODY>
</HTML>

	