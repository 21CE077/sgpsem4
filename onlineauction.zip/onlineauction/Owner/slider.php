<section id="featured">
	 
	<!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
              <li>
                <img src="img/slides/1.jpg" alt="" style="width:100%;height:450px" />
                
              </li>
              
              <li>
                <img src="img/slides/2.jpg" alt="" style="width:100%;height:450px" />
                
              </li>
			   <li>
                <img src="img/slides/3.jpg" alt="" style="width:100%;height:450px" />
                
              </li>
			   
            </ul>
        </div>
	<!-- end slider -->
 
	</section>