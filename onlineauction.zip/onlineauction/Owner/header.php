<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="img/logo3.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                       <li><a href="ownerhome.php">HOME</a></li>
							<li><a  href="productform.php">PRODUCT</a></li>
							<li><a  href="auctionshow.php">AUCTION</a></li>
							<li><a  href="documentdownload.php">DOCUMENT</a></li>
							<li><a  href="ownerprofile.php">PROFILE</a></li>
							<li><a  href="changepassword.php">CHNAGE PASSWORD</a></li>
							<li><a href="../Main/mainhome.php">LOGOUT</a></li>
					
                    </ul>
                </div>
            </div>
        </div>
	</header>